from rest_framework import serializers
from .models import Snippet


class SnippetDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Snippet
        fields = ['title', 'created', 'code', 'language']


class SnippetListSerializer(serializers.ModelSerializer):

    snip_detail = serializers.HyperlinkedIdentityField(view_name='snip:snippet-detail')

    class Meta:
        model = Snippet
        fields = ['title', 'snip_detail']