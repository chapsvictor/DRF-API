from django.urls import path
from .views import SnippetListView, SnippetDetailView


app_name ='snip'

urlpatterns = [
    path('snippets/', SnippetListView.as_view(), name='snippet-list'),
    path('snippets/<int:pk>/', SnippetDetailView.as_view(), name='snippet-detail')
]