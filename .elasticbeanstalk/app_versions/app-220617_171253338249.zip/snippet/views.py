from django.shortcuts import render
from rest_framework.generics import ListAPIView, CreateAPIView, RetrieveAPIView
from .serializers import SnippetDetailSerializer, SnippetListSerializer
from .models import Snippet
from rest_framework.pagination import LimitOffsetPagination


class SnippetListView(ListAPIView):
    queryset = Snippet.objects.all()
    serializer_class = SnippetListSerializer
    pagination_class = LimitOffsetPagination


class SnippetDetailView(RetrieveAPIView):
    queryset = Snippet.objects.all()
    serializer_class = SnippetDetailSerializer

