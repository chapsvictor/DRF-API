from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet, ModuleViewSet

router = DefaultRouter()

router.register('student', StudentViewSet, basename='student_view')
router.register('module', ModuleViewSet, basename='module_view')

urlpatterns = [
    path('', include(router.urls))
]
