from rest_framework import serializers
from school.models import Module, Student


class ModuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Module
        fields = ['id', 'title', 'module_duration', 'class_room']


class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['id', 'modules', 'name', 'age', 'grade']
        # depth = 1


