from rest_framework import viewsets
from school.models import Student, Module
from .serializers import StudentSerializer, ModuleSerializer
from rest_framework.response import Response


class StudentViewSet(viewsets.ModelViewSet):
    serializer_class = StudentSerializer

    def get_queryset(self):
        student = Student.objects.all()
        return student

    # def get(self, request, *args, **kwargs):
    #     qs = Student.objects.all()
    #     serializer = StudentSerializer(data=qs)
    #     return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        new_student = Student.objects.create(name=request.data['name'], age=request.data['age'], grade=request.data['grade'])

        new_student.save()
        for module in request.data['modules']:
            module_obj = Module.objects.get(module_name=module['module_name'])
            new_student.modules.add(module_obj)
        serializer = StudentSerializer(data=new_student)
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response(serializer.data)
        return Response(serializer.errors)




class ModuleViewSet(viewsets.ModelViewSet):
    serializer_class = ModuleSerializer

    def get_queryset(self):
        module = Module.objects.all()
        return module

