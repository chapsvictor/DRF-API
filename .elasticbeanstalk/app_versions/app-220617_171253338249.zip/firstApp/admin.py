from django.contrib import admin
from .models import CarSpecs, CarPlan


admin.site.register(CarSpecs)
admin.site.register(CarPlan)