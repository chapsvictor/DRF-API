from django.conf.urls import url
from django.urls import path, include
from .views import firstfunction
from rest_framework import routers
from .views import CarSpecViewSet, CarPlanViewSet

router = routers.DefaultRouter()
router.register('car-specs', CarSpecViewSet, basename='car_spec_view')
router.register('car-plans', CarPlanViewSet, basename='car_spec_view')

urlpatterns = [
    path('first/', firstfunction, name='first_function'),
    path('', include(router.urls)),
]
