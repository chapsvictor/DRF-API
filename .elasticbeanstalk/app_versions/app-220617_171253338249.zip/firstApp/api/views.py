from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import viewsets
from firstApp.api.serializer import CarSpecSerializer, CarPlanSerializer
from firstApp.models import CarSpecs, CarPlan


@api_view()
@permission_classes([IsAuthenticated])
def firstfunction(request):
    # request.query_params refers to things passed with the endpoint on the browser
    print(request.query_params)
    return Response({'message': 'first api view'})


class CarSpecViewSet(viewsets.ModelViewSet):
    serializer_class = CarSpecSerializer
    throttle_scope = 'cars'

    def get_queryset(self):
        qs = CarSpecs.objects.all()
        return qs

    def retrieve(self, request, *args, **kwargs):
        print(kwargs)
        params = kwargs
        params_list = params['pk'].split('-')
        # print(params_list[0])
        qs = CarSpecs.objects.filter(car_brand=params_list[0], production_year=params_list[1])
        # qs = CarSpecs.objects.all()
        serializer = CarSpecSerializer(qs, many=True)
        # print(serializer.data)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        qs = CarSpecs.objects.create(car_plan=CarPlan.objects.get(id=request.data["car_plan"]),
                                     car_brand=request.data['car_brand'],
                                     car_model=request.data['car_model'],
                                     production_year=request.data['production_year'],
                                     car_body=request.data['car_body'],
                                     engine_type=request.data['engine_type'],

                                     )
        serializer = CarSpecSerializer(data=qs)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def destroy(self, request, *args, **kwargs):
        print(request.user.is_staff)

        if request.user.is_staff:
            # if request.user == 'admin'
            qs = self.get_object()
            qs.delete()
            return Response('CarSpec was successfully deleted')
        return Response('only admin can delete CarSpec')

    def update(self, request, *args, **kwargs):
        car_object = self.get_object()

        car_plan = CarPlan.objects.get(plan_name=request.data['plan_name'])
        car_object.car_plan = car_plan
        car_object.car_brand = request.data['car_brand']
        car_object.car_model = request.data['car_model']
        car_object.production_year = request.data['production_year']
        car_object.car_body = request.data['car_body']
        car_object.engine_type = request.data['engine_type']
        car_object.save()
        serializer = CarSpecSerializer(data=car_object)
        if serializer.is_valid():
            return Response(serializer.data)
        return Response(serializer.errors)

    def partial_update(self, request, *args, **kwargs):
        car_object = self.get_object()
        data = request.data

        try:
            car_plan = CarPlan.objects.get(plan_name=request.data['plan_name'])
            car_object.car_plan = car_plan
        except KeyError:
            pass
        car_object.car_model = request.data.get('car_model', car_object.car_model)
        car_object.car_brand = request.data.get('car_brand', car_object.car_brand)
        car_object.engine_type = request.data.get('engine_type', car_object.engine_type)
        car_object.car_body = request.data.get('car_body', car_object.car_body)
        car_object.production_year = request.data.get('production_year', car_object.production_year)
        car_object.save()

        serializer = CarSpecSerializer(data=car_object, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)


class CarPlanViewSet(viewsets.ModelViewSet):
    serializer_class = CarPlanSerializer

    def get_queryset(self):
        qs = CarPlan.objects.all()
        return qs
