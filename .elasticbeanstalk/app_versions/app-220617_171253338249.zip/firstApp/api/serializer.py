from rest_framework import serializers
from firstApp.models import CarSpecs, CarPlan


class CarPlanSerializer(serializers.ModelSerializer):
    cars = serializers.StringRelatedField(many=True)

    class Meta:
        model = CarPlan
        fields = ['id', 'plan_name', 'years_of_warranty', 'finance_plan', 'cars']
        ordering = ['id']
        # depth = 1


class CarSpecSerializer(serializers.ModelSerializer):

    class Meta:
        model = CarSpecs
        fields = ('id', 'car_plan', 'car_model', 'production_year', 'car_brand', 'engine_type', 'car_body',)
        depth = 1

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['car_plan'] = CarPlanSerializer(instance.car_plan).data
        return response
