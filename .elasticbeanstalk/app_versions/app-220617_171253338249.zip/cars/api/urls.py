from django.urls import path
from .views import CarsApiView


urlpatterns = [
    path('cars/<int:car_id>', CarsApiView.as_view(), name='cars_list'),
    path('cars', CarsApiView.as_view(), name='cars_list')
]
