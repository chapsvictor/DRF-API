from cars.models import Cars
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import CarsSerializer


class CarsApiView(APIView):
    serializer_class = CarsSerializer

    def get_queryset(self):
        cars = Cars.objects.all()
        return cars

    def get(self, request, car_id):

        if car_id is not None:
            car = Cars.objects.get(id=car_id)
            serializer = CarsSerializer(car)
            return Response(serializer.data)
        cars = self.get_queryset()
        serializer = CarsSerializer(cars, many=True)

        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        new_car = Cars.objects.create(
            car_model=request.data['car_model'],
            car_brand=request.data['car_brand'],
            engine_type=request.data['engine_type'],
            car_body=request.data['car_body'],
            production_year=request.data['production_year']
        )

        serializer = CarsSerializer(data=new_car)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def put(self, request, car_id):
        car = Cars.objects.get(id=car_id)
        car.car_model = request.data['car_model'],
        car.car_brand = request.data['car_brand'],
        car.engine_type = request.data['engine_type'],
        car.car_body = request.data['car_body'],
        car.production_year = request.data['production_year']

        car.save()
        serializer = CarsSerializer(data=car)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def patch(self, request, car_id):
        car_object = Cars.objects.get(id=car_id)
        car_object.car_model = request.data.get('car_model', car_object.car_model),
        car_object.car_brand = request.data.get('car_brand', car_object.car_brand)
        car_object.engine_type = request.data.get('engine_type', car_object.engine_type),
        car_object.car_body = request.data.get('car_body', car_object.car_body),
        car_object.production_year = request.data.get('production_year', car_object.production_year)

        car_object.save()
        serializer = CarsSerializer(car_object)
        return Response(serializer.data)