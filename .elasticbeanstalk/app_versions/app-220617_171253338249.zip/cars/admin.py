from django.contrib import admin
from cars.models import Cars

admin.site.register(Cars)

# Register your models here.
