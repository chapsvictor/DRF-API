from postApp.api.serializers import PostsSerializer, PostRatesSerializer
from rest_framework import viewsets
from rest_framework.response import Response
from postApp.models import Posts, PostRates
from django.core.mail import send_mail
import threading


class HandleNotification(threading.Thread):
    def __init__(self, message, subject,  recipient_list):
        self.message = message
        self.subject = subject
        self.recipient_list = recipient_list
        threading.Thread.__init__(self)

    def run(self):
        from_email = 'adebayovictordare@yahoo.com'
        send_mail(self.message, self.subject, from_email, self.recipient_list, fail_silently=False)


class PostViewSet(viewsets.ModelViewSet):
    serializer_class = PostsSerializer

    def sending_email(self, message, subject, recipient_list):
        from_email = 'adebayovictordare@yahoo.com'
        send_mail(subject, message, from_email, recipient_list, fail_silently=False)

    def get_queryset(self):
        posts = Posts.objects.all()
        return posts

    def create(self, request, *args, **kwargs):
        new_rate = PostRates.objects.create(likes=request.data['rates']['likes'], dislikes=request.data['rates']['dislikes']) 
        new_rate.save()

        new_post = Posts.objects.create(post_title=request.data['post_title'], post_body=request.data['post_body'], rates=new_rate)
        new_post.save()
        HandleNotification('this is a post-app notification', "notification", ['adebayovictordare@yahoo.com', ]).start()

        serializer = PostsSerializer(data=new_post)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)


class PostRatesViewSet(viewsets.ModelViewSet):
    serializer_class = PostRatesSerializer

    def get_queryset(self):
        rates = PostRates.objects.all()
        
        return rates
    
    def get(self, request, *args, **kwargs):
        rates = self.get_queryset()
        serializer = PostRatesSerializer(data=rates)
        return Response(serializer.data)
