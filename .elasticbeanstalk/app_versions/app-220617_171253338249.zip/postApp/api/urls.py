from django.urls import path, include
from .views import PostRatesViewSet, PostViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('post', PostViewSet, basename='posts')
router.register('posts-rates', PostRatesViewSet, basename='posts-rates')

urlpatterns = [
    path('', include(router.urls))
]

