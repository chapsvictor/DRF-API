from rest_framework import serializers
from postApp.models import Posts, PostRates


class PostsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Posts
        fields = ('id', 'post_title', 'post_body', 'rates')

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['rates'] = PostRatesSerializer(instance.rates).data
        return response


class PostRatesSerializer(serializers.ModelSerializer):
    class Meta:
        model = PostRates
        fields = '__all__'
