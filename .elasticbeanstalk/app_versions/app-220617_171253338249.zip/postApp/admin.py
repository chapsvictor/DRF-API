from django.contrib import admin
from .models import Posts, PostRates

admin.site.register(Posts)
admin.site.register(PostRates)
