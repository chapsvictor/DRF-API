from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import WeatherViewSet

router = DefaultRouter()
router.register('forecast', WeatherViewSet, basename='fore-cast')

urlpatterns = [
    path('', include(router.urls))
]

