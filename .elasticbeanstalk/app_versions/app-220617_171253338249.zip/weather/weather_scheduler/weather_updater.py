from apscheduler.schedulers.background import BackgroundScheduler
from weather.views import WeatherViewSet


def start():
    scheduler = BackgroundScheduler()
    weather = WeatherViewSet()
    scheduler.add_job(weather.save_weather_data, 'interval', minutes=1, id="weather_001", replace_existing=True)
    scheduler.start()



