from rest_framework import serializers
from .models import Forecast


class WeatherSerializer(serializers.ModelSerializer):
    class Meta:
        model = Forecast
        fields = "__all__"
