from django.shortcuts import render
from rest_framework import viewsets
from .serializers import WeatherSerializer
from .models import Forecast
import requests


class WeatherViewSet(viewsets.ModelViewSet):
    serializer_class = WeatherSerializer

    def get_queryset(self):
        data = Forecast.objects.all()
        return data

    def get_weather_data(self):
        url = 'https://api.openweathermap.org/data/2.5/weather?lat=38.6752399&lon=-0.8099623&appid=51c252c6839dc92d3e398fb794804073'
        api_request = requests.get(url)

        try:
            api_request.raise_for_status()
            return api_request.json()
        except:
            return None

    def save_weather_data(self):
        weather_data = self.get_weather_data()
        print(weather_data)
        if weather_data is not None:
            try:
                weather_object = Forecast.objects.create(temperature=weather_data['main']['temp'],
                                                         description=weather_data['weather'][0]['description'],
                                                         city=weather_data['name'])
                weather_object.save()
            except:
                pass

