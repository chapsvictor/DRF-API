from django.apps import AppConfig


class WeatherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'weather'

    # def ready(self):
    #     print('launching scheduler....')
    #     from .weather_scheduler import weather_updater
    #     weather_updater.start()
